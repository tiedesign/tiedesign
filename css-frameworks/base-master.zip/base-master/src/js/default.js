// Default JavaScript Functions and Initiations
$(document).ready(function() {

  // Functions go here...
  
}); // end document ready
